package kr.human.memo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootEx09MemoMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEx09MemoMybatisApplication.class, args);
	}

}
