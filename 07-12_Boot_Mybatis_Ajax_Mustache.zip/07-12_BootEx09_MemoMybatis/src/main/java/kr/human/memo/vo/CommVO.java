package kr.human.memo.vo;

import lombok.Data;

@Data
public class CommVO {
	private int    idx;
	private int    p;
	private int    s;
	private int    b;
	private String mode;
}
